﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MVCSeries1.Migrations
{
    public partial class InitialFixed : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Serie_Director_DirectorId",
                table: "Serie");

            migrationBuilder.AlterColumn<decimal>(
                name: "Price",
                table: "Serie",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "DirectorId",
                table: "Serie",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Serie_Director_DirectorId",
                table: "Serie",
                column: "DirectorId",
                principalTable: "Director",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Serie_Director_DirectorId",
                table: "Serie");

            migrationBuilder.AlterColumn<decimal>(
                name: "Price",
                table: "Serie",
                type: "decimal(18,2)",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)");

            migrationBuilder.AlterColumn<int>(
                name: "DirectorId",
                table: "Serie",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_Serie_Director_DirectorId",
                table: "Serie",
                column: "DirectorId",
                principalTable: "Director",
                principalColumn: "Id");
        }
    }
}
