﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MVCSeries1.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using MVCSeries1.Areas.Identity.Data;

namespace MVCSeries1.Data
{
    public class MVCSeries1Context : IdentityDbContext<MVCSerie1User>
    {
        public MVCSeries1Context (DbContextOptions<MVCSeries1Context> options)
            : base(options)
        {
        }

        public DbSet<MVCSeries1.Models.Serie> Serie { get; set; } = default!;

        public DbSet<MVCSeries1.Models.Director>? Director { get; set; }

        public DbSet<MVCSeries1.Models.Actor>? Actor { get; set; }

        public DbSet<MVCSeries1.Models.Review>? Review { get; set; }

        public DbSet<MVCSeries1.Models.UserSeries>? UserSeries { get; set; }

        public DbSet<ActorSerie> ActorSerie { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
            /*builder.Entity<ActorSerie>()
                .HasOne<Actor>(p => p.Actor)
                .WithMany(p => p.Series)
                .HasForeignKey(p => p.ActorId);

            builder.Entity<ActorSerie>()
                .HasOne<Serie>(p => p.Serie)
                .WithMany(p => p.Actors)
                .HasForeignKey(p => p.SerieId);

            builder.Entity<Serie>()
                .HasOne<Director>(p => p.Director)
                .WithMany(p => p.Series)
                .HasForeignKey(p => p.DirectorId);

            builder.Entity<Review>()
                .HasOne<Serie>(p => p.Serie)
                .WithMany(p => p.Reviews)
                .HasForeignKey(p => p.SerieId);

            builder.Entity<UserSeries>()
                .HasOne<Serie>(p => p.Serie)
                .WithMany(p => p.UsersSeries)
                .HasForeignKey(p => p.SerieId);
        }*/
    }
}
