﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Humanizer.Localisation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MVCSeries1.Data;
using MVCSeries1.Models;
using MVCSeries1.ViewModels;

namespace MVCSeries1.Controllers
{
    public class SeriesController : Controller
    {
        private readonly MVCSeries1Context _context;

        public SeriesController(MVCSeries1Context context)
        {
            _context = context;
        }

        // GET: Series
        public async Task<IActionResult> Index(string searchString)
        {
            IQueryable<Serie> series = _context.Serie.AsQueryable();
            if (!string.IsNullOrEmpty(searchString))
            {
                series = series.Where(s => s.Title.Contains(searchString));
            }
            
            series = series.Include(m => m.Director)
            .Include(m => m.Actors).ThenInclude(m => m.Actor);
            var serieTitleVM = new SerieTitleViewModel
            {
                Series = await series.ToListAsync()
            };
            return View(serieTitleVM);
        }

        // GET: Series/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Serie == null)
            {
                return NotFound();
            }

            var serie = await _context.Serie
                .Include(s => s.Director)
                .Include(s => s.Actors).ThenInclude(s => s.Actor)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (serie == null)
            {
                return NotFound();
            }

            var reviews = await _context.Review
                .Where(r => r.SerieId == id)
                .Select(r => r.Comment)
                .ToListAsync();

            ViewBag.Reviews = reviews;

            return View(serie);
        }

        // GET: Series/Create
  
        public IActionResult Create()
        {
            ViewData["DirectorId"] = new SelectList(_context.Set<Director>(), "Id", "FullName");
            ViewBag.Actors = new SelectList(_context.Set<Actor>(), "Id", "FullName");
            return View();
        }

        // POST: Series/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
      
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,ReleaseDate,Description,Cover,Price,DirectorId")] Serie serie, IFormFile file1, List<int> selectedActors)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (file1 != null && file1.Length > 0)
                    {
                        var fileName1 = Path.GetFileName(file1.FileName);
                        var filePath1 = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles", fileName1);

                        using (var stream = new FileStream(filePath1, FileMode.Create))
                        {
                            await file1.CopyToAsync(stream);
                        }

                        serie.Cover = "../UploadedFiles/" + fileName1;

                    }

                    if (selectedActors != null && selectedActors.Count > 0)
                    {
                        serie.Actors = new List<ActorSerie>();
                        foreach (var actorId in selectedActors)
                        {
                            var actor = await _context.Actor.FirstOrDefaultAsync(a => a.Id == actorId);
                            if (actor != null)
                            {
                                serie.Actors.Add(new ActorSerie { Actor = actor });
                            }
                        }
                    }

                    _context.Add(serie);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error ocurred.");
                }
            }
            ViewData["DirectorId"] = new SelectList(_context.Set<Director>(), "Id", "FullName", serie.DirectorId);
            ViewBag.Actors = new SelectList(_context.Set<Actor>(), "Id", "FullName");
            return View(serie);
        }

        // GET: Series/Edit/5
        
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Serie == null)
            {
                return NotFound();
            }
            var serie = _context.Serie.Where(s => s.Id == id).Include(s => s.Actors).First();
            //var serie = await _context.Serie.FindAsync(id);
            if (serie == null)
            {
                return NotFound();
            }

            var actors = _context.Actor.AsEnumerable();
            actors = actors.OrderBy(s => s.FullName);
            SerieActorsEditViewModel viewmodel = new SerieActorsEditViewModel
            {
                Serie = serie,
                ActorList = new MultiSelectList(actors, "Id", "FullName"),
                SelectedActors = serie.Actors.Select(sa => sa.ActorId)
            };


            ViewData["DirectorId"] = new SelectList(_context.Director, "Id", "FullName", serie.DirectorId);
            return View(viewmodel);
        }

        // POST: Series/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, SerieActorsEditViewModel viewmodel)
        {
            if (id != viewmodel.Serie.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try { 
                _context.Update(viewmodel.Serie);
                await _context.SaveChangesAsync();
                IEnumerable<int> newActorList = viewmodel.SelectedActors;
                IEnumerable<int> prevActorList = _context.ActorSerie.Where(s => s.SerieId == id).Select(s => s.ActorId);
                IQueryable<ActorSerie> toBeRemoved = _context.ActorSerie.Where(s => s.SerieId == id);
                if (newActorList != null)
                {
                    toBeRemoved = toBeRemoved.Where(s => !newActorList.Contains(s.ActorId));
                    foreach (int actorId in newActorList)
                    {
                        if (!prevActorList.Any(s => s == actorId))
                        {
                            _context.ActorSerie.Add(new ActorSerie { ActorId = actorId, SerieId = id });
                        }
                    }
                }
                _context.ActorSerie.RemoveRange(toBeRemoved);
                await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SerieExists(viewmodel.Serie.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["DirectorId"] = new SelectList(_context.Director, "Id", "FullName", viewmodel.Serie.DirectorId);
            return View(viewmodel);
        }

        // GET: Series/Delete/5
       
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Serie == null)
            {
                return NotFound();
            }

            var serie = await _context.Serie
                .Include(s => s.Director)
                .Include(s => s.Actors).ThenInclude(s => s.Actor)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (serie == null)
            {
                return NotFound();
            }

            return View(serie);
        }

        // POST: Series/Delete/5
       
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Serie == null)
            {
                return Problem("Entity set 'MVCSeries1Context.Serie'  is null.");
            }
            var serie = await _context.Serie.FindAsync(id);
            if (serie != null)
            {
                _context.Serie.Remove(serie);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SerieExists(int id)
        {
          return (_context.Serie?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
