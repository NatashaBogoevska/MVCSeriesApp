﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MVCSeries1.Data;
using MVCSeries1.Models;

namespace MVCSeries1.Controllers
{
    public class UserSeriesController : Controller
    {
        private readonly MVCSeries1Context _context;

        public UserSeriesController(MVCSeries1Context context)
        {
            _context = context;
        }

        // GET: UserSeries
        public async Task<IActionResult> Index()
        {
            var mVCSeries1Context = _context.UserSeries.Include(u => u.Serie);
            return View(await mVCSeries1Context.ToListAsync());
        }

        // GET: UserSeries/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.UserSeries == null)
            {
                return NotFound();
            }

            var userSeries = await _context.UserSeries
                .Include(u => u.Serie)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (userSeries == null)
            {
                return NotFound();
            }

            return View(userSeries);
        }

        // GET: UserSeries/Create
        public IActionResult Create()
        {
            ViewData["SerieId"] = new SelectList(_context.Serie, "Id", "Title");
            return View();
        }

        // POST: UserSeries/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,AppUser,SerieId")] UserSeries userSeries)
        {
            if (ModelState.IsValid)
            {
                _context.Add(userSeries);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["SerieId"] = new SelectList(_context.Serie, "Id", "Title", userSeries.SerieId);
            return View(userSeries);
        }

        // GET: UserSeries/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.UserSeries == null)
            {
                return NotFound();
            }

            var userSeries = await _context.UserSeries.FindAsync(id);
            if (userSeries == null)
            {
                return NotFound();
            }
            ViewData["SerieId"] = new SelectList(_context.Serie, "Id", "Title", userSeries.SerieId);
            return View(userSeries);
        }

        // POST: UserSeries/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,AppUser,SerieId")] UserSeries userSeries)
        {
            if (id != userSeries.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(userSeries);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserSeriesExists(userSeries.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["SerieId"] = new SelectList(_context.Serie, "Id", "Title", userSeries.SerieId);
            return View(userSeries);
        }

        // GET: UserSeries/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.UserSeries == null)
            {
                return NotFound();
            }

            var userSeries = await _context.UserSeries
                .Include(u => u.Serie)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (userSeries == null)
            {
                return NotFound();
            }

            return View(userSeries);
        }

        // POST: UserSeries/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.UserSeries == null)
            {
                return Problem("Entity set 'MVCSeries1Context.UserSeries'  is null.");
            }
            var userSeries = await _context.UserSeries.FindAsync(id);
            if (userSeries != null)
            {
                _context.UserSeries.Remove(userSeries);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool UserSeriesExists(int id)
        {
          return (_context.UserSeries?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
