﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using MVCSeries1.Data;
using MVCSeries1.Models;
using MVCSeries1.ViewModels;

namespace MVCSeries1.Controllers
{
    public class DirectorsController : Controller
    {
        private readonly MVCSeries1Context _context;

        public DirectorsController(MVCSeries1Context context)
        {
            _context = context;
        }

        // GET: Directors
        public async Task<IActionResult> Index(string genderString)
        {
            IQueryable<Director> directors = _context.Director.AsQueryable();
            IQueryable<string> genderQuery = _context.Director.OrderBy(d => d.Gender).Select(d => d.Gender).Distinct();

            if (!string.IsNullOrEmpty(genderString))
            {
                directors = directors.Where(d => d.Gender == genderString);
            }

           

            var directorGenderVM = new DirectorGenderViewModel
            {
                Genders = new SelectList(await genderQuery.ToListAsync()),
                Directors = await directors.ToListAsync()
               };

        return View(directorGenderVM);

        
        }

        // GET: Directors/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Director == null)
            {
                return NotFound();
            }

            var director = await _context.Director
                .FirstOrDefaultAsync(m => m.Id == id);
            if (director == null)
            {
                return NotFound();
            }

            var series = await _context.Serie
                .Where(s => s.DirectorId == id)
                .Select(r => r.Title)
                .ToListAsync();

            ViewBag.Series = series;

            return View(director);
        }

        // GET: Directors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Directors/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FirstName,LastName,Gender,BirthDate")] Director director)
        {
            if (ModelState.IsValid)
            {
                _context.Add(director);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(director);
        }

        // GET: Directors/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Director == null)
            {
                return NotFound();
            }

            var director = await _context.Director.FindAsync(id);
            if (director == null)
            {
                return NotFound();
            }
            return View(director);
        }

        // POST: Directors/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FirstName,LastName,Gender,BirthDate")] Director director)
        {
            if (id != director.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(director);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DirectorExists(director.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(director);
        }

        // GET: Directors/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Director == null)
            {
                return NotFound();
            }

            var director = await _context.Director
                .FirstOrDefaultAsync(m => m.Id == id);
            if (director == null)
            {
                return NotFound();
            }

            return View(director);
        }

        // POST: Directors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Director == null)
            {
                return Problem("Entity set 'MVCSeries1Context.Director'  is null.");
            }
            var director = await _context.Director.FindAsync(id);
            if (director != null)
            {
                _context.Director.Remove(director);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DirectorExists(int id)
        {
          return (_context.Director?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
