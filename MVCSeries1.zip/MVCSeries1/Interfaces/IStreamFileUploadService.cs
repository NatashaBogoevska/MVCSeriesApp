﻿using Microsoft.AspNetCore.WebUtilities;

namespace MVCSeries1.Interfaces
{
    public interface IStreamFileUploadService
    {
        Task<bool> UploadFile(MultipartReader reader, MultipartSection section);
    }
}
