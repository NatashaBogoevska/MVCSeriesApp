﻿using MVCSeries1.Models;
using System.Collections.Generic;

namespace MVCSeries1.ViewModels
{
    public class SerieTitleViewModel
    {
        public IList<Serie> Series { get; set; }
        public string SearchString { get; set; }
    }
}
