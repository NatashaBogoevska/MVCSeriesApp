﻿using Microsoft.AspNetCore.Mvc.Rendering;
using MVCSeries1.Models;
using System.Collections.Generic;

namespace MVCSeries1.ViewModels
{
    public class SerieActorsEditViewModel
    {
        public Serie Serie { get; set; }
        public IEnumerable<int>? SelectedActors { get; set; }
        public IEnumerable<SelectListItem> ? ActorList { get; set; }

    }
}
