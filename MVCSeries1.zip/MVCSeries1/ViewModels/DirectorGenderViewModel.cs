﻿using Microsoft.AspNetCore.Mvc.Rendering;
using MVCSeries1.Models;
using System.Collections.Generic;


namespace MVCSeries1.ViewModels
{
    public class DirectorGenderViewModel
    {
        public IList<Director> Directors { get; set; }
        public SelectList Genders { get; set; }
        public string GenderString { get; set; }
    }
}
