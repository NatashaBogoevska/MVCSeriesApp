﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace MVCSeries1.Areas.Identity.Data;

// Add profile data for application users by adding properties to the MVCSerie1User class
public class MVCSerie1User : IdentityUser
{
}

