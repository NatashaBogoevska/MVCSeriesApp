﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCSeries1.Models
{
    public class UserSeries
    {

        public int Id { get; set; }

        [StringLength(450)]
        public string AppUser { get; set; }

        public int SerieId { get; set; }
        public Serie? Serie { get; set; }

    }
}
