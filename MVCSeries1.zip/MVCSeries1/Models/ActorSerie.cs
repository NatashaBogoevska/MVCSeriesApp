﻿namespace MVCSeries1.Models
{
    public class ActorSerie
    {

        public int Id { get; set; }
        public int ActorId { get; set; }
        public Actor Actor { get; set; }
        public int SerieId { get; set; }
        public Serie Serie { get; set; }
    }
}
