﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using MVCSeries1.Areas.Identity.Data;
using MVCSeries1.Data;
using MVCSeries1.Models;


namespace MVCSeries1.Models
{
    public class SeedData
    {
        public static async Task CreateUserRoles(IServiceProvider serviceProvider)
        {
            var RoleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var UserManager = serviceProvider.GetRequiredService<UserManager<MVCSerie1User>>();
            IdentityResult roleResult;

            //Add Admin Role
            var roleCheck = await RoleManager.RoleExistsAsync("Admin");
            if(!roleCheck) { roleResult = await RoleManager.CreateAsync(new IdentityRole("Admin")); }

            MVCSerie1User user = await UserManager.FindByEmailAsync("admin@mvcserie.com");
            if(user == null)
            {
                var User = new MVCSerie1User();
                User.Email = "admin@mvcserie.com";
                User.UserName = "admin@mvcserie.com";
                string userPWD = "Admin123";
                IdentityResult chkUser = await UserManager.CreateAsync(User, userPWD);
                //add default user to role admin
                if (chkUser.Succeeded) { var result1 = await UserManager.AddToRoleAsync(User, "Admin"); }
            }
        }

        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MVCSeries1Context(
                serviceProvider.GetRequiredService<
                    DbContextOptions<MVCSeries1Context>>()))
            {
                CreateUserRoles(serviceProvider).Wait();
                //Look for any series.
                if (context.Serie.Any() || context.Director.Any() || context.Actor.Any())
                {
                    return; //DB has been seeded
                }

                context.Director.AddRange(
                 new Director { /*Id = 1, */ FirstName = "James", LastName = "Burrows", BirthDate = DateTime.Parse("1940-12-30"), Gender = "Male",
                     Series = new List<Serie>
                     {
                         new Serie
                         {
                             //Id = 1
                             Title = "Friends",
                             ReleaseDate = DateTime.Parse("1994-9-22"),
                             Description = "Comedy series about a tight-knit group of friends living in Manhattan. It also covers their interactions with their families, their lovers, and various colleagues over a period of several years.",
                             Cover = "https://static.tvtropes.org/pmwiki/pub/images/rp16851_friends_apartment_6.jpg",
                             Price = 10,
                             DirectorId = 1,

                             Reviews = new List<Review>
                             {
                                 new Review { AppUser = "user1@user.com", Comment = "Awesome!", Rating = 10, SerieId = 1 },
                                 new Review { AppUser = "user2@user.com", Comment = "Very good!", Rating = 9, SerieId = 1 }
                             },

                             UsersSeries = new List<UserSeries>
                             {
                                 new UserSeries { AppUser = "user1@user.com", SerieId = 1 },
                                 new UserSeries { AppUser = "user2@user.com", SerieId = 1 }
                             }
                         }
                     }
                 },
                    new Director { /*Id = 2, */ FirstName = "Peter", LastName = "Nowalk", BirthDate = DateTime.Parse("1953-1-1"), Gender = "Male",
                        Series = new List<Serie>
                        {
                            new Serie
                            {
                                //Id = 2
                                Title = "How To Get Away With Murder",
                                ReleaseDate = DateTime.Parse("2014-9-25"),
                                Description = "Annalise Keating, a lawyer, teaches a class from which she selects the brightest students to assist her in cases at the firm. Soon, she finds her life entangled with four students.",
                                Cover = "https://resizing.flixster.com/3iTSamgyYCbAXKmDjqyFWPnIQ18=/206x305/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p14387045_b_v8_aa.jpg",
                                Price = 7,
                                DirectorId = 2,

                                Reviews = new List<Review>
                                {
                                    new Review { AppUser = "user3@user.com", Comment = "Not my cup of tea.", Rating = 5, SerieId = 2 },
                                    new Review { AppUser = "user4@user.com", Comment = "It was really unpredictable!", Rating = 8, SerieId = 2 }
                                },

                                UsersSeries = new List<UserSeries>
                                {
                                    new UserSeries { AppUser = "user3@user.com", SerieId = 2 },
                                    new UserSeries { AppUser = "user4@user.com", SerieId = 2 }
                                }
                            }
                        }
                    },

                    new Director { /*Id = 3, */ FirstName = "Josh", LastName = "Schwartz", BirthDate = DateTime.Parse("1976-8-6"), Gender = "Male",
                        Series = new List<Serie>
                        {
                            new Serie
                            {
                                //Id = 3
                                Title = "Gossip Girl",
                                ReleaseDate = DateTime.Parse("2007-9-19"),
                                Description = "Blair Waldorf is a popular student at her private school and envied by one and all. But, her perfect life is unsettled when her ex-best friend enrols in the same institution.",
                                Cover = "https://m.media-amazon.com/images/I/91I8ElmqRZL._SL1500_.jpg",
                                Price = 15,
                                DirectorId = 3,

                                Reviews = new List<Review>
                                {
                                    new Review { AppUser = "user5@user.com", Comment = "Very childish!", Rating = 3, SerieId = 3 },
                                    new Review { AppUser = "user6@user.com", Comment = "Fantastic!", Rating = 10, SerieId = 3 }
                                },

                                UsersSeries = new List<UserSeries>
                                {
                                    new UserSeries { AppUser = "user5@user.com", SerieId = 3 },
                                    new UserSeries { AppUser = "user6@user.com", SerieId = 3 }
                                }
                            }
                        }
                    }

        );
                context.SaveChanges();

                context.Actor.AddRange(
                    new Actor { /*Id=1, */ FirstName="Jennifer", LastName = "Aniston", BirthDate = DateTime.Parse("1969-2-11")},
                    new Actor { /*Id=2, */ FirstName="Lisa", LastName = "Kudrow", BirthDate = DateTime.Parse("1963-7-30")},
                    new Actor { /*Id=3, */ FirstName="Matthew", LastName = "Perry", BirthDate = DateTime.Parse("1969-10-28")},
                    new Actor { /*Id=4, */ FirstName="Blake", LastName="Lively", BirthDate=DateTime.Parse("1987-8-25")},
                    new Actor { /*Id=5, */ FirstName="Leighton", LastName="Meester", BirthDate=DateTime.Parse("1986-4-9")},
                    new Actor { /*Id=6, */ FirstName="Ed", LastName="Westwick", BirthDate=DateTime.Parse("1987-6-27")},
                    new Actor { /*Id=7, */ FirstName="Viola", LastName="Davis", BirthDate=DateTime.Parse("1965-8-11")},
                    new Actor { /*Id=8, */ FirstName="Aja", LastName="King", BirthDate=DateTime.Parse("1985-1-11")},
                    new Actor { /*Id=9, */ FirstName = "Jack", LastName = "Falahee", BirthDate = DateTime.Parse("1989-2-20") }
                    );
                context.SaveChanges();

                context.ActorSerie.AddRange(
                    new ActorSerie { ActorId=1, SerieId=1},
                    new ActorSerie { ActorId=2, SerieId=1},
                    new ActorSerie { ActorId=3, SerieId=1},
                    new ActorSerie { ActorId=4, SerieId=3},
                    new ActorSerie { ActorId=5, SerieId=3},
                    new ActorSerie { ActorId=6, SerieId=3},
                    new ActorSerie { ActorId=7, SerieId=2},
                    new ActorSerie { ActorId=8, SerieId=2},
                    new ActorSerie { ActorId=9, SerieId=2}
                    );
                context.SaveChanges();

            }
        }
    }
}

