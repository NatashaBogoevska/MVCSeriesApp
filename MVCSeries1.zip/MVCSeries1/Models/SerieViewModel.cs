﻿using Microsoft.AspNetCore.Http;
namespace MVCSeries1.Models
{
    public class SerieViewModel
    {
        public string Title { get; set; }
        public DateTime? ReleaseDate { get; set; }
        public string Description { get; set; }
        public IFormFile CoverFile { get; set; }
        public string Genre { get; set; }
        public decimal? Price { get; set; }
        public int DirectorId { get; set; }
    }
}
