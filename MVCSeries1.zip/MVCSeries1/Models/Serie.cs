﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;

namespace MVCSeries1.Models
{
    public class Serie
    {

        public int Id { get; set; }

        [Display(Name = "Title")]
        [StringLength(100)]
        [Required]
        public string Title { get; set; }

        [Display(Name = "Release Date")]
        [DataType(DataType.Date)] 
        public DateTime? ReleaseDate { get; set; }

        public string? Description { get; set; }

        [Display(Name = "Cover")]
        public string? Cover { get; set; }

        [Range(1,100)]
        [DataType(DataType.Currency)]
        [Display(Name = "Price")]
        public decimal Price { get; set; }

        [NotMapped]
        public double? AverageRating { get; set; }

        [Display(Name = "Director")]
        public int DirectorId { get; set; }
        public Director Director { get; set; }

        public ICollection<ActorSerie>? Actors { get; set; }
        public ICollection<Review>? Reviews { get; set; }
        public ICollection<UserSeries> UsersSeries { get; set; }

        [NotMapped]
        [Display(Name = "Rating")]
        public double CalculateRating
        {
            get
            {
                if(Reviews == null || Reviews.Count == 0)
                {
                    return 0.0;
                }

                double sum = 0;
                int reviewCount = 0;
                foreach (var review in Reviews)
                {
                    if (review.Rating.HasValue)
                    {
                        sum += review.Rating.Value;
                        reviewCount++;
                    }
                }

                if(reviewCount == 0)
                {
                    return 0.0;
                }

                return Math.Round(sum / reviewCount, 2);
            }
        }

    }
}
