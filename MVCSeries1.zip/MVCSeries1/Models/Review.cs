﻿using System.ComponentModel.DataAnnotations;

namespace MVCSeries1.Models
{
    public class Review
    {

        public int Id { get; set; }

        [StringLength(450)]
        public string AppUser { get; set; }

        [StringLength(500)]
        public string Comment { get; set; }

        public int? Rating { get; set; }

        public int SerieId { get; set; }
        public Serie? Serie { get; set; }
    }
}
